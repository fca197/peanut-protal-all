create table t_shift
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    shift_code       varchar(255)                       null,
    shift_name       varchar(255)                       null,
    factory_id       varchar(255)                       null,
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '班次表';

create index idx_t_shift_factory_id
    on t_shift (factory_id);

create index idx_t_shift_tenant_id
    on t_shift (tenant_id);

