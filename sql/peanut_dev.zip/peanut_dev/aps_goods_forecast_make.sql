create table aps_goods_forecast_make
(
    id                             bigint auto_increment comment 'ID 自增'
        primary key,
    goods_id                       bigint                             null comment '商品ID',
    forecast_make_month_no         varchar(255)                       null,
    forecast_make_month_name       varchar(255)                       null,
    forecast_make_month_begin_date varchar(255)                       null,
    forecast_make_month_end_date   varchar(255)                       null,
    factory_id                     varchar(255)                       null,
    tenant_id                      bigint                             null comment '租户ID',
    is_delete                      bigint   default 0                 null comment '0 正常，非0已删除',
    create_time                    datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                      bigint                             null comment '创建人',
    update_time                    datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                      bigint                             null comment '修改人',
    trace_id                       varchar(64)                        null comment '调用链路',
    version_num                    int      default 0                 null comment '版本号',
    month                          varchar(255)                       null,
    weeks                          text                               null,
    forecast_main_id               varchar(255)                       null,
    is_deploy                      tinyint                            null,
    bom_use_begin_date             varchar(255)                       null,
    bom_use_end_date               varchar(255)                       null,
    create_user_name               varchar(128)                       null comment '创建人姓名',
    update_user_name               varchar(128)                       null comment '修改人姓名'
)
    comment '商品预测-制造';

create index idx_aps_goods_forecast_make_factory_id
    on aps_goods_forecast_make (factory_id);

create index idx_aps_goods_forecast_make_forecast_main_id
    on aps_goods_forecast_make (forecast_main_id);

create index idx_aps_goods_forecast_make_goods_id
    on aps_goods_forecast_make (goods_id);

create index idx_aps_goods_forecast_make_tenant_id
    on aps_goods_forecast_make (tenant_id);

