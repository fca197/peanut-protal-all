create table aps_scheduling_version_day
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    version_id       bigint                             null,
    current_day      varchar(255)                       null,
    has_enough       tinyint                            null,
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '排产版本天表';

create index idx_aps_scheduling_version_day_tenant_id
    on aps_scheduling_version_day (tenant_id);

create index idx_aps_scheduling_version_day_version_id
    on aps_scheduling_version_day (version_id);

