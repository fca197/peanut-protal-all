create table aps_bom
(
    id                  bigint auto_increment comment 'ID 自增'
        primary key,
    bom_code            varchar(255)                       null comment 'bom 编码',
    bom_name            varchar(255)                       null comment 'bom 名称',
    bom_cost_price      decimal(15, 6)                     null comment '成本价',
    bom_cost_price_unit varchar(255)                       null comment '单位',
    bom_inventory       decimal(15, 6)                     null comment '库存',
    tenant_id           bigint                             null comment '租户ID',
    is_delete           bigint   default 0                 null comment '0 正常，非0已删除',
    create_time         datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by           bigint                             null comment '创建人',
    update_time         datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by           bigint                             null comment '修改人',
    trace_id            varchar(64)                        null comment '调用链路',
    version_num         int      default 0                 null comment '版本号',
    group_id            bigint                             null comment '组ID',
    supply_mode         varchar(4)                         null comment '供给方式 make, buy',
    use_unit            varchar(64)                        null comment '使用单位',
    bom_unit            varchar(64)                        null comment '零件单位',
    produce_process_id  bigint                             null comment '制造路径',
    delivery_cycle_day  int      default 1                 null comment '到货周期',
    aps_bom_supplier_id bigint                             null comment '供应商ID',
    create_user_name    varchar(128)                       null comment '创建人姓名',
    update_user_name    varchar(128)                       null comment '修改人姓名'
)
    comment 'BOM 清单';

create index idx_aps_bom_tenant_id
    on aps_bom (tenant_id);

create index idx_g_id
    on aps_bom (group_id)
    comment '组';

