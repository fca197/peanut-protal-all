create table aps_scheduling_version
(
    id                               bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_version_no            varchar(255)                         null,
    tenant_id                        bigint                               null comment '租户ID',
    is_delete                        bigint     default 0                 null comment '0 正常，非0已删除',
    create_time                      datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                        bigint                               null comment '创建人',
    update_time                      datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                        bigint                               null comment '修改人',
    trace_id                         varchar(64)                          null comment '调用链路',
    version_num                      int        default 0                 null comment '版本号',
    scheduling_version_name          varchar(255)                         null,
    scheduling_constraints_id        varchar(255)                         null,
    header_list                      text                                 null,
    capacity_header_list             text                                 null,
    capacity_date_list               varchar(1024)                        null,
    scheduling_day_count             bigint                               null,
    version_step                     smallint                             null,
    version_step_error               varchar(255)                         null,
    bom_total_end_date               date                                 null comment 'bom汇总结束日期',
    start_date                       date                                 null comment '开始时间',
    use_factory_make_capacity        tinyint(1) default 0                 null comment '使用工厂产能约束',
    use_goods_make_capacity          tinyint(1) default 0                 null comment '使用商品产能约束',
    use_sale_config_make_capacity    tinyint(1) default 0                 null comment '使用销售配置产能约束',
    use_project_config_make_capacity tinyint(1) default 0                 null comment '使用工程配置产能约束',
    factory_id_list                  json                                 null comment '工厂ID',
    goods_id_list                    json                                 null comment '商品ID',
    create_user_name                 varchar(128)                         null comment '创建人姓名',
    update_user_name                 varchar(128)                         null comment '修改人姓名'
)
    comment '排产版本表';

create index idx_aps_scheduling_version_scheduling_constraints_id
    on aps_scheduling_version (scheduling_constraints_id);

create index idx_aps_scheduling_version_tenant_id
    on aps_scheduling_version (tenant_id);

