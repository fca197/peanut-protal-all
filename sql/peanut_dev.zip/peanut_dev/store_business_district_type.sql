create table store_business_district_type
(
    id                          bigint auto_increment comment 'id'
        primary key,
    business_district_type_name varchar(64)                        null comment '类型名称',
    business_district_type_code varchar(64)                        null comment '类型编码',
    business_district_type_desc varchar(512)                       null comment '类型描述',
    is_delete                   bigint   default 0                 null comment '0 正常，非0已删除',
    create_time                 datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                   bigint                             null comment '创建人',
    update_time                 datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                   varchar(255)                       null,
    trace_id                    varchar(64)                        null comment '调用链路',
    version_num                 int      default 0                 null comment '版本号',
    tenant_id                   varchar(255)                       null,
    create_user_name            varchar(128)                       null comment '创建人姓名',
    update_user_name            varchar(128)                       null comment '修改人姓名'
)
    comment '商圈类型';

