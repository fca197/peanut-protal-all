create table aps_rolling_forecast_order
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    roll_code        varchar(64)                        not null comment '唯一编码',
    roll_name        varchar(64)                        not null comment '名称',
    factory_id       bigint                             null comment '工厂Id',
    begin_status_id  bigint                             null comment '开始节点',
    end_status_id    bigint                             null comment '结束节点',
    begin_time       date                               not null comment '开始时间',
    end_time         date                               not null comment '结束时间',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '滚动预测';

