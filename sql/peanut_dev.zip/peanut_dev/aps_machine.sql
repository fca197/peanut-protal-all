create table aps_machine
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    machine_no       varchar(32)                        not null comment '机器编号',
    machine_name     varchar(32)                        not null comment '机器名称',
    factory_id       bigint                             null comment '工厂ID',
    max_power        decimal(15, 4)                     null comment '最大功率',
    sort_index       bigint   default 0                 null comment '排序索引',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment 'aps 生产机器';

create index idx_tenant_id
    on aps_machine (tenant_id);

