create table aps_order_goods_bom
(
    id                   bigint auto_increment comment 'ID 自增'
        primary key,
    order_id             bigint                                   null comment '订单ID',
    goods_bom_id         bigint                                   null comment 'aps_goods_bom ID ',
    goods_id             bigint                                   null comment '商品ID',
    group_id             bigint                                   null comment '零件组ID',
    bom_id               bigint                                   null comment '商品ID',
    bom_code             varchar(255)                             null comment 'bom 编码',
    bom_name             varchar(255)                             null comment 'bom 名称',
    bom_usage            decimal(15, 6)                           null comment '使用量',
    bom_unit             varchar(255)                             null comment '单位',
    bom_cost_price       decimal(15, 6)                           null comment '成本价',
    bom_cost_price_unit  varchar(255)                             null comment '单位',
    bom_use_work_station bigint                                   null comment '使用工位',
    bom_use_expression   varchar(255)                             null comment '使用表达式',
    bom_inventory        decimal(15, 6) default 0.000000          null comment '库存',
    is_follow            tinyint(1)     default 0                 null comment '是否关注',
    factory_id           bigint                                   null comment '工厂ID',
    tenant_id            bigint                                   null comment '租户ID',
    is_delete            bigint         default 0                 null comment '0 正常，非0已删除',
    create_time          datetime       default CURRENT_TIMESTAMP null comment '创建时间',
    create_by            bigint                                   null comment '创建人',
    update_time          datetime       default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by            bigint                                   null comment '修改人',
    trace_id             varchar(64)                              null comment '调用链路',
    version_num          int            default 0                 null comment '版本号',
    goods_status_id      bigint                                   null comment '状态',
    bom_use_date         date                                     null comment '使用时间',
    create_user_name     varchar(128)                             null comment '创建人姓名',
    update_user_name     varchar(128)                             null comment '修改人姓名'
)
    comment 'BOM 清单';

create index idx_order_id
    on aps_order_goods_bom (order_id);

