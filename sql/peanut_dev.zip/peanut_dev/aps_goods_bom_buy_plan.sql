create table aps_goods_bom_buy_plan
(
    id                bigint auto_increment comment 'ID 自增'
        primary key,
    plan_name         varchar(255)                       null comment '计划名称',
    plan_total_amount decimal(15, 6)                     null comment '总价',
    plan_source       varchar(255)                       null comment '计划来源',
    plan_remark       varchar(255)                       null comment '计划备注',
    buy_plan_type     varchar(32)                        null comment '购买类型',
    is_follow         tinyint  default 0                 null comment '是否关注',
    tenant_id         bigint                             null comment '租户ID',
    is_delete         bigint   default 0                 null comment '0 正常，非0已删除',
    create_time       datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by         bigint                             null comment '创建人',
    update_time       datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by         bigint                             null comment '修改人',
    trace_id          varchar(64)                        null comment '调用链路',
    version_num       int      default 0                 null comment '版本号',
    bom_use_date      longtext                           null comment '日期',
    create_user_name  varchar(128)                       null comment '创建人姓名',
    update_user_name  varchar(128)                       null comment '修改人姓名'
)
    comment 'BOM 购买计划';

create index idx_aps_goods_bom_plan_tenant_id
    on aps_goods_bom_buy_plan (tenant_id);

