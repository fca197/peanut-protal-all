create table aps_order_goods_history
(
    id               bigint                             not null comment 'ID 自增'
        primary key,
    factory_id       bigint                             null comment '工厂ID',
    goods_id         bigint                             null comment '商品ID',
    goods_name       varchar(255)                       null comment '商品名称',
    year             int                                null comment '年份',
    month_count01    decimal(10, 6)                     null comment '1月销售数量',
    month_ratio01    decimal(10, 6)                     null comment '1月销售占比',
    month_count02    decimal(10, 6)                     null comment '2月销售数量',
    month_ratio02    decimal(10, 6)                     null comment '2月销售占比',
    month_count03    decimal(10, 6)                     null comment '3月销售数量',
    month_ratio03    decimal(10, 6)                     null comment '3月销售占比',
    month_count04    decimal(10, 6)                     null comment '4月销售数量',
    month_ratio04    decimal(10, 6)                     null comment '4月销售占比',
    month_count05    decimal(10, 6)                     null comment '5月销售数量',
    month_ratio05    decimal(10, 6)                     null comment '5月销售占比',
    month_count06    decimal(10, 6)                     null comment '6月销售数量',
    month_ratio06    decimal(10, 6)                     null comment '6月销售占比',
    month_count07    decimal(10, 6)                     null comment '7月销售数量',
    month_ratio07    decimal(10, 6)                     null comment '7月销售占比',
    month_count08    decimal(10, 6)                     null comment '8月销售数量',
    month_ratio08    decimal(10, 6)                     null comment '8月销售占比',
    month_count09    decimal(10, 6)                     null comment '9月销售数量',
    month_ratio09    decimal(10, 6)                     null comment '9月销售占比',
    month_count10    decimal(10, 6)                     null comment '10月销售数量',
    month_ratio10    decimal(10, 6)                     null comment '10月销售占比',
    month_count11    decimal(10, 6)                     null comment '11月销售数量',
    month_ratio11    decimal(10, 6)                     null comment '11月销售占比',
    month_count12    decimal(10, 6)                     null comment '12月销售数量',
    month_ratio12    decimal(10, 6)                     null comment '12月销售占比',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '历史订单记录';

create index idx_good
    on aps_order_goods_history (goods_id);

