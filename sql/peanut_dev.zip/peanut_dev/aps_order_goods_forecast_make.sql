create table aps_order_goods_forecast_make
(
    id                 bigint auto_increment comment 'ID 自增'
        primary key,
    order_id           bigint                             null,
    goods_id           bigint                             null comment '商品ID',
    goods_status_id    bigint                             null comment '订单状态',
    goods_status_name  varchar(255)                       null comment '节点名称',
    forecast_make_date date                               null comment '预计制造日期',
    factory_id         bigint                             null comment '工厂ID',
    tenant_id          bigint                             null comment '租户ID',
    is_delete          bigint   default 0                 null comment '0 正常，非0已删除',
    create_time        datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by          bigint                             null comment '创建人',
    update_time        datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by          bigint                             null comment '修改人',
    trace_id           varchar(64)                        null comment '调用链路',
    version_num        int      default 0                 null comment '版本号',
    create_user_name   varchar(128)                       null comment '创建人姓名',
    update_user_name   varchar(128)                       null comment '修改人姓名'
)
    comment '订单商品节点预测表';

create index idx_aps_order_goods_factory_id
    on aps_order_goods_forecast_make (factory_id);

create index idx_aps_order_goods_goods_id
    on aps_order_goods_forecast_make (goods_id);

create index idx_aps_order_goods_order_id
    on aps_order_goods_forecast_make (order_id);

create index idx_aps_order_goods_tenant_id
    on aps_order_goods_forecast_make (tenant_id);

