create table aps_produce_process_item
(
    id                       bigint auto_increment comment 'ID 自增'
        primary key,
    produce_process_id       bigint                             null comment '生产路径 Id aps_produce_process',
    machine_workstation_id   bigint                             null comment '机器工作站ID',
    machine_workstation_name varchar(128)                       null comment '机器工作站名称',
    goods_status_id          bigint                             null comment '商品状态',
    goods_status_name        varchar(128)                       null comment '订单状态',
    max_power                decimal(15, 4)                     null comment '最大功率',
    use_time                 bigint                             null comment '耗时时常',
    machine_id               bigint                             null comment '机器ID',
    machine_name             varchar(128)                       null comment '机器工作站名称',
    status_id                bigint                             null comment '状态ID',
    machine_use_time_second  bigint                             null comment '耗时（秒）',
    tenant_id                bigint                             null comment '租户ID',
    is_delete                bigint   default 0                 null comment '0 正常，非0已删除',
    create_time              datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                bigint                             null comment '创建人',
    update_time              datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                bigint                             null comment '修改人',
    trace_id                 varchar(64)                        null comment '调用链路',
    version_num              int      default 0                 null comment '版本号',
    factory_id               bigint                             null comment '工厂ID',
    sort_index               bigint                             null comment '排序',
    create_user_name         varchar(128)                       null comment '创建人姓名',
    update_user_name         varchar(128)                       null comment '修改人姓名'
)
    comment 'aps 生产机器';

create index idx_produce_process_id
    on aps_produce_process_item (produce_process_id);

create index idx_tenant_id
    on aps_produce_process_item (tenant_id);

