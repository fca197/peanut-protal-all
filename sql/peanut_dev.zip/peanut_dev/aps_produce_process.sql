create table aps_produce_process
(
    id                   bigint auto_increment comment 'ID 自增'
        primary key,
    produce_process_no   varchar(32)                        not null comment '生产路径编码',
    produce_process_name varchar(32)                        not null comment '生产路径名称',
    factory_id           bigint                             null comment '工厂ID',
    is_default           tinyint  default 0                 null comment '是否默认',
    tenant_id            bigint                             null comment '租户ID',
    is_delete            bigint   default 0                 null comment '0 正常，非0已删除',
    create_time          datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by            bigint                             null comment '创建人',
    update_time          datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by            bigint                             null comment '修改人',
    trace_id             varchar(64)                        null comment '调用链路',
    version_num          int      default 0                 null comment '版本号',
    create_user_name     varchar(128)                       null comment '创建人姓名',
    update_user_name     varchar(128)                       null comment '修改人姓名'
)
    comment 'aps 生产路径';

create index idx_tenant_id
    on aps_produce_process (tenant_id);

