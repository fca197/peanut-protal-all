create table aps_room_config
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    room_id          varchar(255)                       null,
    section_id       bigint                             null,
    station_id       bigint                             null,
    execute_time     varchar(255)                       null,
    factory_id       bigint                             null comment '工厂ID',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    status_id        bigint                             null,
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '房间配置表';

create index idx_aps_room_config_room_id
    on aps_room_config (room_id);

create index idx_aps_room_config_section_id
    on aps_room_config (section_id);

create index idx_aps_room_config_station_id
    on aps_room_config (station_id);

create index idx_aps_room_config_status_id
    on aps_room_config (status_id);

create index idx_aps_room_config_tenant_id
    on aps_room_config (tenant_id);

