create table jcx_buy_order_item
(
    id                     bigint auto_increment comment 'ID 自增'
        primary key,
    order_id               bigint                             null,
    goods_id               bigint                             null comment '商品ID',
    goods_cost_price       decimal(15, 6)                     null comment '成本价',
    goods_buy_count        decimal(15, 6)                     null comment '购买数',
    goods_unit             varchar(255)                       null,
    goods_cost_price_total decimal(15, 6)                     null comment '成本总额',
    goods_buy_remark       varchar(255)                       null,
    is_delete              bigint   default 0                 null comment '0 正常，非0已删除',
    tenant_id              bigint                             null comment '租户ID',
    create_time            datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by              bigint                             null comment '创建人',
    update_time            datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by              bigint                             null comment '修改人',
    trace_id               varchar(64)                        null comment '调用链路',
    is_used                varchar(255)                       null,
    version_num            int      default 0                 null comment '版本号',
    goods_name             varchar(255)                       null,
    supplier_id            varchar(255)                       null,
    supplier_name          varchar(255)                       null,
    create_user_name       varchar(128)                       null comment '创建人姓名',
    update_user_name       varchar(128)                       null comment '修改人姓名'
)
    comment '进销存-采购订单明细表';

create index idx_jcx_buy_order_item_goods_id
    on jcx_buy_order_item (goods_id);

create index idx_jcx_buy_order_item_order_id
    on jcx_buy_order_item (order_id);

create index idx_jcx_buy_order_item_supplier_id
    on jcx_buy_order_item (supplier_id);

create index idx_jcx_buy_order_item_tenant_id
    on jcx_buy_order_item (tenant_id);

