create table aps_goods_sale_project_config
(
    id                       bigint auto_increment comment 'ID 自增'
        primary key,
    goods_id                 bigint                             null comment '商品ID',
    factory_id               varchar(255)                       null,
    project_config_id        bigint                             null,
    project_config_name      varchar(255)                       null,
    project_config_parent_id bigint                             null,
    quantity                 smallint                           null,
    sale_config_id           bigint                             null,
    sale_config_name         varchar(255)                       null,
    sale_config_parent_id    bigint                             null,
    tenant_id                bigint                             null comment '租户ID',
    is_delete                bigint   default 0                 null comment '0 正常，非0已删除',
    create_time              datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                bigint                             null comment '创建人',
    update_time              datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                bigint                             null comment '修改人',
    trace_id                 varchar(64)                        null comment '调用链路',
    version_num              int      default 0                 null comment '版本号',
    current_index            tinyint                            null,
    create_user_name         varchar(128)                       null comment '创建人姓名',
    update_user_name         varchar(128)                       null comment '修改人姓名'
)
    comment '项目配置';

create index idx_aps_goods_sale_project_config_factory_id
    on aps_goods_sale_project_config (factory_id);

create index idx_aps_goods_sale_project_config_goods_id
    on aps_goods_sale_project_config (goods_id);

create index idx_aps_goods_sale_project_config_project_config_id
    on aps_goods_sale_project_config (project_config_id);

create index idx_aps_goods_sale_project_config_project_config_parent_id
    on aps_goods_sale_project_config (project_config_parent_id);

create index idx_aps_goods_sale_project_config_sale_config_id
    on aps_goods_sale_project_config (sale_config_id);

create index idx_aps_goods_sale_project_config_sale_config_parent_id
    on aps_goods_sale_project_config (sale_config_parent_id);

create index idx_aps_goods_sale_project_config_tenant_id
    on aps_goods_sale_project_config (tenant_id);

