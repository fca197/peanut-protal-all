create table base_resource
(
    id                      bigint auto_increment comment 'ID 自增'
        primary key,
    resource_code           varchar(64)                          null comment '菜单编码',
    resource_name           varchar(64)                          null comment '菜单名称',
    resource_url            varchar(512)                         null comment '菜单URL',
    next_level_resource_url varchar(255)                         null comment '下个版本',
    resource_comment        varchar(512)                         null comment '组建路径',
    resource_icon           varchar(64)                          null comment '菜单图标',
    resource_type           varchar(64)                          null comment '菜单类型',
    is_button               tinyint(1) default 0                 null comment '是否按钮 0 否,1 是',
    is_hidden               tinyint                              null comment '是否因此 0否,1是',
    parent_id               bigint                               null comment '父菜单ID',
    path                    varchar(512)                         null comment '菜单路径',
    sort_index              int                                  null comment '排序',
    is_delete               bigint     default 0                 null comment '0 正常，非0已删除',
    create_time             datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by               bigint                               null comment '创建人',
    update_time             datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by               bigint                               null comment '修改人',
    trace_id                varchar(64)                          null comment '调用链路',
    version_num             int        default 0                 null comment '版本号',
    tenant_id               bigint                               null comment '租户ID',
    create_user_name        varchar(128)                         null comment '创建人姓名',
    update_user_name        varchar(128)                         null comment '修改人姓名'
)
    comment '资源';

