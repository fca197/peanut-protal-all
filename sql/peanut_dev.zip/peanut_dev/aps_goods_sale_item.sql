create table aps_goods_sale_item
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    goods_id         bigint                             null comment '商品ID',
    sale_goods_id    bigint                             null,
    sale_config_id   bigint                             null,
    use_forecast     decimal(15, 6)                     null,
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    supplier_status  varchar(255)                       null,
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '商品销售配置';

create index idx_aps_goods_sale_item_goods_id
    on aps_goods_sale_item (goods_id);

create index idx_aps_goods_sale_item_sale_config_id
    on aps_goods_sale_item (sale_config_id);

create index idx_aps_goods_sale_item_tenant_id
    on aps_goods_sale_item (tenant_id);

