create table aps_scheduling_goods_bom
(
    id                   bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_id        bigint                             null comment '排产ID',
    order_id             bigint                             null comment '订单ID',
    goods_id             bigint                             null comment '商品ID',
    goods_status_id      bigint                             null comment '订单状态',
    bom_id               bigint                             null comment '零件ID',
    bom_code             varchar(255)                       null comment 'bom 编码',
    bom_name             varchar(255)                       null comment 'bom 名称',
    bom_usage            decimal(15, 6)                     null comment '使用量',
    bom_unit             varchar(255)                       null comment '单位',
    bom_cost_price       decimal(15, 6)                     null comment '成本价',
    bom_cost_price_unit  varchar(255)                       null comment '单位',
    bom_use_work_station bigint                             null comment '使用工位',
    bom_use_date         date                               null comment '使用时间',
    factory_id           bigint                             null comment '工厂ID',
    tenant_id            bigint                             null comment '租户ID',
    is_delete            bigint   default 0                 null comment '0 正常，非0已删除',
    create_time          datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by            bigint                             null comment '创建人',
    update_time          datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by            bigint                             null comment '修改人',
    trace_id             varchar(64)                        null comment '调用链路',
    version_num          int      default 0                 null comment '版本号',
    goods_bom_id         bigint                             null comment '商品bom表id',
    create_user_name     varchar(128)                       null comment '创建人姓名',
    update_user_name     varchar(128)                       null comment '修改人姓名'
)
    comment '订单商品零件表';

create index idx_aps_scheduling_goods_bom_factory_id
    on aps_scheduling_goods_bom (factory_id);

create index idx_aps_scheduling_goods_bom_goods_id
    on aps_scheduling_goods_bom (goods_id);

create index idx_aps_scheduling_goods_bom_scheduling_id
    on aps_scheduling_goods_bom (scheduling_id);

create index idx_aps_scheduling_goods_bom_tenant_id
    on aps_scheduling_goods_bom (tenant_id);

