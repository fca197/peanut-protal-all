create table aps_order_goods
(
    id                     bigint auto_increment comment 'ID 自增'
        primary key,
    order_id               bigint                             null,
    goods_id               bigint                             null comment '商品ID',
    goods_name             varchar(255)                       null,
    goods_remark           varchar(255)                       null,
    goods_amount           decimal(20, 6)                     null comment '总价',
    goods_price            decimal(15, 6)                     null comment '成本价',
    goods_total_price      decimal(15, 6)                     null comment '成本价',
    goods_unit             varchar(255)                       null,
    goods_unit_price       decimal(15, 6)                     null comment '成本价',
    goods_unit_total_price decimal(15, 6)                     null comment '成本价',
    goods_status_id        bigint                             null comment '订单状态',
    factory_id             bigint                             null comment '工厂ID',
    aps_status_id          bigint                             null comment '订单状态',
    tenant_id              bigint                             null comment '租户ID',
    is_delete              bigint   default 0                 null comment '0 正常，非0已删除',
    create_time            datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by              bigint                             null comment '创建人',
    update_time            datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by              bigint                             null comment '修改人',
    trace_id               varchar(64)                        null comment '调用链路',
    version_num            int      default 0                 null comment '版本号',
    create_user_name       varchar(128)                       null comment '创建人姓名',
    update_user_name       varchar(128)                       null comment '修改人姓名'
)
    comment '订单商品表';

create index idx_aps_order_goods_factory_id
    on aps_order_goods (factory_id);

create index idx_aps_order_goods_goods_id
    on aps_order_goods (goods_id);

create index idx_aps_order_goods_order_id
    on aps_order_goods (order_id);

create index idx_aps_order_goods_tenant_id
    on aps_order_goods (tenant_id);

