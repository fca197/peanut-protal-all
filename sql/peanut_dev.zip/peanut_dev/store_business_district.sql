create table store_business_district
(
    id                              bigint auto_increment comment 'id'
        primary key,
    brand_id                        bigint                             null comment '品牌ID',
    business_district_name          varchar(128)                       null comment '名称',
    business_district_code          varchar(64)                        null comment '编码',
    business_district_desc          varchar(1024)                      null comment '描述',
    business_district_address       varchar(1024)                      null comment '地址',
    country_code                    varchar(10)                        null comment '国家编码',
    province_code                   varchar(10)                        null comment '城市编码',
    city_code                       varchar(10)                        null comment '城市编码',
    area_code                       varchar(10)                        null comment '城市编码',
    country_name                    varchar(100)                       null comment '国家名称',
    province_name                   varchar(100)                       null comment '省份名称',
    city_name                       varchar(100)                       null comment '城市名称',
    area_name                       varchar(100)                       null comment '区县名称',
    business_district_radius        bigint                             null comment '半径',
    business_district_search_radius int                                null comment '查询半径',
    business_district_level_id      bigint                             null comment '商圈级别ID',
    business_district_type_id       bigint                             null comment '商圈类别ID',
    center_lat                      varchar(64)                        null comment '纬度',
    center_lng                      varchar(64)                        null comment '经度',
    location_geo                    point                              null comment '中心点 geo格式',
    is_delete                       bigint   default 0                 null comment '0 正常，非0已删除',
    create_time                     datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                       bigint                             null comment '创建人',
    update_time                     datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                       varchar(255)                       null,
    trace_id                        varchar(64)                        null comment '调用链路',
    version_num                     int      default 0                 null comment '版本号',
    tenant_id                       varchar(255)                       null,
    create_user_name                varchar(128)                       null comment '创建人姓名',
    update_user_name                varchar(128)                       null comment '修改人姓名'
)
    comment '商圈';

