create table aps_scheduling_version_item_pre
(
    id                    bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_version_id bigint                             null comment '排产版本ID',
    current_day           varchar(255)                       null comment '当前日期',
    old_schedule_date     date                               null comment '上次排程',
    order_id              bigint                             null comment '订单ID',
    goods_id              bigint                             null comment '商品ID',
    goods_name            varchar(64)                        null comment '产品名称',
    number_index          int                                null comment '生产序号',
    factory_id            bigint                             null comment '工厂id',
    urgency_level         int      default 0                 null comment '订单紧急度',
    factory_name          varchar(64)                        null comment '工厂名称',
    tenant_id             bigint                             null comment '租户ID',
    show_field            json                               null comment '显示字段',
    is_delete             bigint   default 0                 null comment '0 正常，非0已删除',
    create_time           datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by             bigint                             null comment '创建人',
    update_time           datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by             varchar(255)                       null,
    trace_id              varchar(64)                        null comment '调用链路',
    version_num           int      default 0                 null comment '版本号',
    order_no              varchar(64)                        not null comment '订单号',
    legacy_order          tinyint                            null comment '遗留订单',
    create_user_name      varchar(128)                       null comment '创建人姓名',
    update_user_name      varchar(128)                       null comment '修改人姓名'
)
    comment '排产下发订单预览';

create index idx_current_day
    on aps_scheduling_version_item_pre (current_day);

create index idx_factory_id
    on aps_scheduling_version_item_pre (factory_id);

create index idx_scheduling_version_id
    on aps_scheduling_version_item_pre (scheduling_version_id);

