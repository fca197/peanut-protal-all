create table aps_scheduling_day_config_version_detail_machine_use_time
(
    id                 bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_day_id  bigint                             null comment '排程ID',
    machine_id         bigint                             null comment '机器ID',
    use_time           bigint                             null comment '耗时',
    use_usage_rate     decimal(15, 6)                     null comment '使用率',
    make_produce_count int                                null comment '商品数',
    tenant_id          bigint                             null comment '租户ID',
    is_delete          bigint   default 0                 null comment '0 正常，非0已删除',
    create_time        datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by          bigint                             null comment '创建人',
    update_time        datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by          bigint                             null comment '修改人',
    trace_id           varchar(64)                        null comment '调用链路',
    version_num        int      default 0                 null comment '版本号',
    create_user_name   varchar(128)                       null comment '创建人姓名',
    update_user_name   varchar(128)                       null comment '修改人姓名'
)
    comment '排程结果机器使用率';

create index idx_scheduling_day_id
    on aps_scheduling_day_config_version_detail_machine_use_time (scheduling_day_id);

