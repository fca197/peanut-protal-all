create table aps_order_field_show_template
(
    id                               bigint auto_increment comment 'ID 自增'
        primary key,
    aps_order_user_no                varchar(64)                          null comment '模板编号',
    aps_order_user_name              varchar(64)                          null comment '模板名称',
    is_default                       tinyint(1) default 0                 null comment '是否默认',
    aps_order_sale_config_list       json                                 null comment '销售配置',
    aps_order_order_config_list      json                                 null comment '订单配置',
    aps_order_order_user_config_list json                                 null comment '订单配置',
    tenant_id                        bigint                               null comment '租户ID',
    is_delete                        bigint     default 0                 null comment '0 正常，非0已删除',
    create_time                      datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                        bigint                               null comment '创建人',
    update_time                      datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                        bigint                               null comment '修改人',
    trace_id                         varchar(64)                          null comment '调用链路',
    version_num                      int        default 0                 null comment '版本号',
    create_user_name                 varchar(128)                         null comment '创建人姓名',
    update_user_name                 varchar(128)                         null comment '修改人姓名'
)
    comment '订单显示模板';

