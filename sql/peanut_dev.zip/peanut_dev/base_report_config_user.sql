create table base_report_config_user
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    report_config_id bigint                             not null comment '报表ID',
    sort_index       int      default 0                 null comment '排序',
    col_span         int      default 1                 null comment '宽度 安el-col span 计算',
    height           int      default 1                 null comment '高度',
    report_name      varchar(255)                       null comment '报表名称',
    report_url       varchar(512)                       null comment '报表路径',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '报表配置用户配置';

