create table flow_form
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    form_name        varchar(64)                        null comment '表单名称',
    form_code        varchar(64)                        null comment '表单编码',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '工作流表单表';

create index idx_flow_form_code
    on flow_form (form_code);

create index idx_form_code
    on flow_form (form_code);

