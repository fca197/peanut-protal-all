create table aps_order_goods_bom_kitting_version_order
(
    id                  bigint auto_increment comment 'ID 自增'
        primary key,
    number_index        bigint                             null comment '序号',
    kitting_version_id  bigint                             null comment '齐套版本id',
    order_id            bigint                             null comment '订单ID',
    order_no            varchar(64)                        null comment '订单ID',
    kitting_rate        decimal(5, 2)                      null comment '齐套率',
    kitting_status      varchar(32)                        null comment '齐套状态 已齐套， 部分齐套，未齐套',
    kitting_missing_bom json                               null comment '缺失物料前10 [{id: label}]',
    order_field_01      varchar(32)                        null comment '订单字段',
    order_field_02      varchar(32)                        null comment '订单字段',
    order_field_03      varchar(32)                        null comment '订单字段',
    order_field_04      varchar(32)                        null comment '订单字段',
    order_field_05      varchar(32)                        null comment '订单字段',
    order_field_06      varchar(32)                        null comment '订单字段',
    order_field_07      varchar(32)                        null comment '订单字段',
    order_field_08      varchar(32)                        null comment '订单字段',
    order_field_09      varchar(32)                        null comment '订单字段',
    order_field_10      varchar(32)                        null comment '订单字段',
    order_field_11      varchar(32)                        null comment '订单字段',
    order_field_12      varchar(32)                        null comment '订单字段',
    order_field_13      varchar(32)                        null comment '订单字段',
    order_field_14      varchar(32)                        null comment '订单字段',
    order_field_15      varchar(32)                        null comment '订单字段',
    order_field_16      varchar(32)                        null comment '订单字段',
    order_field_17      varchar(32)                        null comment '订单字段',
    order_field_18      varchar(32)                        null comment '订单字段',
    order_field_19      varchar(32)                        null comment '订单字段',
    order_field_20      varchar(32)                        null comment '订单字段',
    factory_id          bigint                             null comment '工厂ID',
    tenant_id           bigint                             null comment '租户ID',
    is_delete           bigint   default 0                 null comment '0 正常，非0已删除',
    create_time         datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by           bigint                             null comment '创建人',
    update_time         datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by           bigint                             null comment '修改人',
    trace_id            varchar(64)                        null comment '调用链路',
    version_num         int      default 0                 null comment '版本号',
    create_user_name    varchar(128)                       null comment '创建人姓名',
    update_user_name    varchar(128)                       null comment '修改人姓名'
)
    comment '齐套检查订单详情';

create index idx_kitting_version_id
    on aps_order_goods_bom_kitting_version_order (kitting_version_id);

create index idx_order_no
    on aps_order_goods_bom_kitting_version_order (order_no);

