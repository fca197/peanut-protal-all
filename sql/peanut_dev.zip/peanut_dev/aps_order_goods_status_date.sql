create table aps_order_goods_status_date
(
    id                     bigint auto_increment comment 'ID 自增'
        primary key,
    order_id               bigint                             null,
    goods_id               bigint                             null comment '商品ID',
    goods_status_name      varchar(64)                        null comment '状态名称',
    goods_status_id        bigint                             null comment '订单状态',
    factory_id             bigint                             null comment '工厂ID',
    tenant_id              bigint                             null comment '租户ID',
    is_delete              bigint   default 0                 null comment '0 正常，非0已删除',
    create_time            datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by              bigint                             null comment '创建人',
    update_time            datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by              bigint                             null comment '修改人',
    trace_id               varchar(64)                        null comment '调用链路',
    version_num            int      default 0                 null comment '版本号',
    status_index           int      default 0                 null comment '状态索引',
    expect_make_begin_time date                               null comment '预计开始时间',
    expect_make_end_time   date                               null comment '预计结束时间',
    actual_make_begin_time datetime                           null comment '实际开始时间',
    actual_make_end_time   datetime                           null comment '实际结束时间',
    create_user_name       varchar(128)                       null comment '创建人姓名',
    update_user_name       varchar(128)                       null comment '修改人姓名'
)
    comment '订单商品状态表';

create index idx_order_goods_id
    on aps_order_goods_status_date (goods_id);

create index idx_order_id
    on aps_order_goods_status_date (order_id);

