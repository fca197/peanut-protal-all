create table aps_order_user
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    order_id         bigint                             null,
    user_name        varchar(255)                       null,
    user_phone       bigint                             null,
    user_sex         tinyint                            null,
    country_code     varchar(255)                       null,
    province_code    varchar(255)                       null,
    city_code        varchar(255)                       null,
    area_code        varchar(255)                       null,
    user_address     varchar(255)                       null,
    user_remark      varchar(255)                       null,
    factory_id       bigint                             null comment '工厂ID',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '订单用户表';

create index idx_aps_order_user_order_id
    on aps_order_user (order_id);

create index idx_aps_order_user_tenant_id
    on aps_order_user (tenant_id);

