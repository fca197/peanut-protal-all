create table aps_goods
(
    id                 bigint auto_increment comment 'ID 自增'
        primary key,
    goods_name         varchar(255)                       null comment '商品名称',
    goods_remark       varchar(255)                       null comment '商品备注',
    tenant_id          bigint                             null comment '租户ID',
    is_delete          bigint   default 0                 null comment '0 正常，非0已删除',
    create_time        datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by          bigint                             null comment '创建人',
    update_time        datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by          bigint                             null comment '修改人',
    trace_id           varchar(64)                        null comment '调用链路',
    supplier_status    varchar(255)                       null,
    version_num        int      default 0                 null comment '版本号',
    factory_id         bigint                             null comment '工厂ID',
    process_path_id    bigint                             null comment '工艺路线',
    produce_process_id bigint                             null comment '制造流水线ID produceProcess',
    create_user_name   varchar(128)                       null comment '创建人姓名',
    update_user_name   varchar(128)                       null comment '修改人姓名'
)
    comment 'aps 商品表';

create index idx_aps_goods_factory_id
    on aps_goods (factory_id);

create index idx_aps_goods_tenant_id
    on aps_goods (tenant_id);

