create table t_district_code
(
    id          bigint                             null,
    code        varchar(255)                       null,
    name        varchar(255)                       null,
    parent_code varchar(255)                       null,
    path        varchar(255)                       null comment '路径',
    level       tinyint                            null,
    is_delete   bigint   default 0                 null comment '0 正常，非0已删除',
    create_time datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by   bigint                             null comment '创建人',
    update_time datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by   varchar(255)                       null,
    trace_id    varchar(64)                        null comment '调用链路',
    version_num int      default 0                 null comment '版本号',
    tenant_id   varchar(255)                       null
)
    comment '地区代码表';

create index t_district_code_code_index
    on t_district_code (code);

create index t_district_code_parent_code_index
    on t_district_code (parent_code);

create index t_district_code_path_index
    on t_district_code (path);

