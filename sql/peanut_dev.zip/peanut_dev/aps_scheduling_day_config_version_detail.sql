create table aps_scheduling_day_config_version_detail
(
    id                bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_day_id bigint                               null,
    config_biz_type   varchar(255)                         null comment '配置类型 sale,part,bom',
    config_biz_id     bigint                               null comment '配置业务ID',
    config_biz_name   varchar(255)                         null comment '配置业务名称',
    config_biz_num    bigint                               null comment '配置业务数量',
    order_id          bigint                               null comment '订单ID',
    order_no          varchar(255)                         null comment '订单编号',
    room_id           bigint                               null comment '房间id',
    status_id         bigint                               null comment '状态 Id',
    sort_index        int                                  null comment '排序',
    is_match          tinyint(1) default 0                 null comment '是否匹配 0 否,1 是',
    loop_index        int                                  null comment '循环次数',
    loop_enough       tinyint(1) default 0                 null comment '是否满足 0 否,1 是',
    tenant_id         bigint                               null comment '租户ID',
    is_delete         bigint     default 0                 null comment '0 正常，非0已删除',
    create_time       datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by         bigint                               null comment '创建人',
    update_time       datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by         bigint                               null comment '修改人',
    trace_id          varchar(64)                          null comment '调用链路',
    version_num       int        default 0                 null comment '版本号',
    create_user_name  varchar(128)                         null comment '创建人姓名',
    update_user_name  varchar(128)                         null comment '修改人姓名'
)
    comment '排程版本配置明细表';

create index idx_order_id
    on aps_scheduling_day_config_version_detail (order_id);

create index idx_scheduling_day_id
    on aps_scheduling_day_config_version_detail (scheduling_day_id);

