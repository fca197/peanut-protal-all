create table aps_scheduling_day_config_version
(
    id                        bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_day_config_id  bigint                               null comment '配置ID',
    factory_id                bigint                               null comment '工厂ID',
    scheduling_day_version_no varchar(255)                         null comment '排程版本号',
    scheduling_day            date                                 null comment '排程日期',
    search_old                tinyint                              null comment '是否查询历史订单 0否， 1是',
    is_issued_third           tinyint(1) default 0                 null comment '是否下发 0 否,1 是',
    tenant_id                 bigint                               null comment '租户ID',
    is_delete                 bigint     default 0                 null comment '0 正常，非0已删除',
    create_time               datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                 bigint                               null comment '创建人',
    update_time               datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                 bigint                               null comment '修改人',
    trace_id                  varchar(64)                          null comment '调用链路',
    version_num               int        default 0                 null comment '版本号',
    process_id                bigint                               null comment '工艺路径id',
    header_list               varchar(4096)                        null comment '排产日配置版本表头',
    product_type              varchar(10)                          null comment '排产生产类型',
    goods_id_list             json                                 null comment '商品列表',
    sale_config_id_list       json                                 null comment '销售配置ID',
    step_index                tinyint                              null comment '当前步骤',
    order_field_list          json                                 null comment '订单字段',
    order_user_field_list     json                                 null comment '订单用户字段',
    create_user_name          varchar(128)                         null comment '创建人姓名',
    update_user_name          varchar(128)                         null comment '修改人姓名'
)
    comment '排程版本';

