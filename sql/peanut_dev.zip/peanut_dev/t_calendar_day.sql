create table t_calendar_day
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    calendar_id      bigint                             null comment '日历ID',
    day_month        smallint                           null comment '制造数',
    day_year         smallint                           null comment '制造数',
    day_1            tinyint  default 0                 null comment '制造数',
    day_2            tinyint  default 0                 null comment '制造数',
    day_3            tinyint  default 0                 null comment '制造数',
    day_4            tinyint  default 0                 null comment '制造数',
    day_5            tinyint  default 0                 null comment '制造数',
    day_6            tinyint  default 0                 null comment '制造数',
    day_7            tinyint  default 0                 null comment '制造数',
    day_8            tinyint  default 0                 null comment '制造数',
    day_9            tinyint  default 0                 null comment '制造数',
    day_10           tinyint  default 0                 null comment '制造数',
    day_11           tinyint  default 0                 null comment '制造数',
    day_12           tinyint  default 0                 null comment '制造数',
    day_13           tinyint  default 0                 null comment '制造数',
    day_14           tinyint  default 0                 null comment '制造数',
    day_15           tinyint  default 0                 null comment '制造数',
    day_16           tinyint  default 0                 null comment '制造数',
    day_17           tinyint  default 0                 null comment '制造数',
    day_18           tinyint  default 0                 null comment '制造数',
    day_19           tinyint  default 0                 null comment '制造数',
    day_20           tinyint  default 0                 null comment '制造数',
    day_21           tinyint  default 0                 null comment '制造数',
    day_22           tinyint  default 0                 null comment '制造数',
    day_23           tinyint  default 0                 null comment '制造数',
    day_24           tinyint  default 0                 null comment '制造数',
    day_25           tinyint  default 0                 null comment '制造数',
    day_26           tinyint  default 0                 null comment '制造数',
    day_27           tinyint  default 0                 null comment '制造数',
    day_28           tinyint  default 0                 null comment '制造数',
    day_29           tinyint  default 0                 null comment '制造数',
    day_30           tinyint  default 0                 null comment '制造数',
    day_31           tinyint  default 0                 null comment '制造数',
    factory_id       bigint                             null comment '工厂ID',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '日历天表';

create index idx_t_calendar_day_calendar_id
    on t_calendar_day (calendar_id);

create index idx_t_calendar_day_factory_id
    on t_calendar_day (factory_id);

create index idx_t_calendar_day_tenant_id
    on t_calendar_day (tenant_id);

