create table aps_goods_forecast_main_goods_data
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    goods_id         bigint                             null comment '商品ID',
    year             varchar(255)                       null,
    month_01         decimal(15, 6)                     null,
    month_02         decimal(15, 6)                     null,
    month_03         decimal(15, 6)                     null,
    month_04         decimal(15, 6)                     null,
    month_05         decimal(15, 6)                     null,
    month_06         decimal(15, 6)                     null,
    month_07         decimal(15, 6)                     null,
    month_08         decimal(15, 6)                     null,
    month_09         decimal(15, 6)                     null,
    month_10         decimal(15, 6)                     null,
    month_11         decimal(15, 6)                     null,
    month_12         decimal(15, 6)                     null,
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        varchar(255)                       null,
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    forecast_main_id bigint                             null,
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '预测商品数据';

