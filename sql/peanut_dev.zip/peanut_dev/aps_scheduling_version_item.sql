create table aps_scheduling_version_item
(
    id                    bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_version_id bigint                             null,
    order_id              bigint                             null,
    order_no              varchar(64)                        null comment '订单号',
    goods_id              bigint                             null comment '商品ID',
    field0                varchar(255)                       null,
    field1                varchar(255)                       null,
    field2                varchar(255)                       null,
    field3                varchar(255)                       null,
    field4                varchar(255)                       null,
    field5                varchar(255)                       null,
    field6                varchar(255)                       null,
    field7                varchar(255)                       null,
    field8                varchar(255)                       null,
    field9                varchar(255)                       null,
    field10               varchar(255)                       null,
    field11               varchar(255)                       null,
    field12               varchar(255)                       null,
    field13               varchar(255)                       null,
    field14               varchar(255)                       null,
    field15               varchar(255)                       null,
    field16               varchar(255)                       null,
    field17               varchar(255)                       null,
    field18               varchar(255)                       null,
    field19               varchar(255)                       null,
    field20               varchar(255)                       null,
    tenant_id             bigint                             null comment '租户ID',
    is_delete             bigint   default 0                 null comment '0 正常，非0已删除',
    create_time           datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by             bigint                             null comment '创建人',
    update_time           datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by             bigint                             null comment '修改人',
    trace_id              varchar(64)                        null comment '调用链路',
    version_num           int      default 0                 null comment '版本号',
    result_type           tinyint                            null,
    number_index          smallint                           null,
    factory_id            varchar(255)                       null,
    create_user_name      varchar(128)                       null comment '创建人姓名',
    update_user_name      varchar(128)                       null comment '修改人姓名'
)
    comment '排产版本项表';

create index idx_aps_scheduling_version_item_factory_id
    on aps_scheduling_version_item (factory_id);

create index idx_aps_scheduling_version_item_goods_id
    on aps_scheduling_version_item (goods_id);

create index idx_aps_scheduling_version_item_order_id
    on aps_scheduling_version_item (order_id);

create index idx_aps_scheduling_version_item_scheduling_version_id
    on aps_scheduling_version_item (scheduling_version_id);

create index idx_aps_scheduling_version_item_tenant_id
    on aps_scheduling_version_item (tenant_id);

