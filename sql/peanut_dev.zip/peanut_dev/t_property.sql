create table t_property
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    tenant_id        bigint                             null comment '租户ID',
    factory_id       bigint                             null comment '工厂ID',
    storey_id        bigint                             null,
    room_id          bigint                             null,
    property_code    varchar(255)                       null,
    property_name    varchar(255)                       null,
    in_use           tinyint                            null,
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '资产属性表';

create index idx_t_property_factory_id
    on t_property (factory_id);

create index idx_t_property_room_id
    on t_property (room_id);

create index idx_t_property_storey_id
    on t_property (storey_id);

create index idx_t_property_tenant_id
    on t_property (tenant_id);

