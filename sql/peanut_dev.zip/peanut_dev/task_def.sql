create table task_def
(
    id               bigint                             not null comment 'ID 自增'
        primary key,
    task_name        varchar(100)                       null comment '任务名称',
    tas_code         varchar(100)                       null comment '任务编号',
    task_remark      text                               null comment '任务备注',
    task_def_content longtext                           null comment '任务名称',
    exec_count       bigint   default 0                 null comment '执行次数',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    exec_loop        int                                null comment '循环次数',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '任务定义';

create index idx_tenant_id
    on task_def (tenant_id);

