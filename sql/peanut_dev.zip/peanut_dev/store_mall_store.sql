create table store_mall_store
(
    id                     bigint auto_increment comment 'ID 自增'
        primary key,
    shopping_mall_id       bigint                             null comment 'store_shopping_mall ID  商场ID',
    mall_store_floor       int                                null comment '楼层',
    mall_store_room_no     int                                null comment '房间号',
    mall_store_status      int                                null comment '状态 0草稿，1可建店，2被锁定，3评审中，4已确址，5已废弃，',
    mall_store_status_mark varchar(512)                       null comment '状态备注',
    tenant_id              bigint                             null comment '租户ID',
    is_delete              bigint   default 0                 null comment '0 正常，非0已删除',
    create_time            datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by              bigint                             null comment '创建人',
    update_time            datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by              bigint                             null comment '修改人',
    trace_id               varchar(64)                        null comment '调用链路',
    version_num            int      default 0                 null comment '版本号',
    create_user_name       varchar(128)                       null comment '创建人姓名',
    update_user_name       varchar(128)                       null comment '修改人姓名'
)
    comment 'store 商场门店';

