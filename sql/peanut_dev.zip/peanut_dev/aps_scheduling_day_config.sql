create table aps_scheduling_day_config
(
    id                       bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_day_config_id bigint                               null comment '配置ID',
    factory_id               bigint                               null comment '工厂ID',
    scheduling_type          varchar(32)                          null comment '排程类型',
    process_id               bigint                               null comment '工艺路径ID',
    make_process_id          bigint                               null comment '制造路径',
    scheduling_day_no        varchar(255)                         null comment '排程版本号',
    scheduling_day_name      varchar(255)                         null comment '排程版本名称',
    is_default               tinyint(1) default 0                 null comment '是否默认 0 否,1 是',
    tenant_id                bigint                               null comment '租户ID',
    is_delete                bigint     default 0                 null comment '0 正常，非0已删除',
    create_time              datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                bigint                               null comment '创建人',
    update_time              datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                bigint                               null comment '修改人',
    trace_id                 varchar(64)                          null comment '调用链路',
    version_num              int        default 0                 null comment '版本号',
    room_config              varchar(1024)                        null comment '车间配置',
    create_user_name         varchar(128)                         null comment '创建人姓名',
    update_user_name         varchar(128)                         null comment '修改人姓名'
)
    comment '排程版本表';

