create table t_check_report_list
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    tenant_id        bigint                             null comment '租户ID',
    factory_id       bigint                             null comment '工厂ID',
    report_id        varchar(255)                       null,
    property_id      bigint                             null,
    remark           varchar(255)                       null,
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    room_id          bigint                             null,
    storey_id        bigint                             null,
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '检查报告明细表';

create index idx_t_check_report_list_factory_id
    on t_check_report_list (factory_id);

create index idx_t_check_report_list_property_id
    on t_check_report_list (property_id);

create index idx_t_check_report_list_report_id
    on t_check_report_list (report_id);

create index idx_t_check_report_list_room_id
    on t_check_report_list (room_id);

create index idx_t_check_report_list_storey_id
    on t_check_report_list (storey_id);

create index idx_t_check_report_list_tenant_id
    on t_check_report_list (tenant_id);

