create table base_dept
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    dept_code        varchar(64)                        null comment '部门编码',
    dept_name        varchar(64)                        null comment '部门名称',
    parent_id        bigint                             null comment '父部门ID',
    path             varchar(512)                       null comment '部门路径',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    tenant_id        bigint                             null comment '租户ID',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '部门表';

