create table jcx_order_item
(
    id                     bigint auto_increment comment 'ID 自增'
        primary key,
    tenant_id              bigint                             null comment '租户ID',
    order_id               bigint                             null,
    order_remark           varchar(255)                       null,
    goods_id               bigint                             null comment '商品ID',
    goods_count            decimal(15, 6)                     null comment '商品量',
    goods_cost_price       decimal(15, 6)                     null comment '成本价',
    goods_sale_price       decimal(15, 6)                     null comment '成本价',
    goods_gross_profit     varchar(255)                       null,
    goods_net_profit       varchar(255)                       null,
    is_delete              bigint   default 0                 null comment '0 正常，非0已删除',
    create_time            datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by              bigint                             null comment '创建人',
    update_time            datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by              bigint                             null comment '修改人',
    trace_id               varchar(64)                        null comment '调用链路',
    version_num            int      default 0                 null comment '版本号',
    goods_total_sale_price decimal(15, 6)                     null comment '成本价',
    create_user_name       varchar(128)                       null comment '创建人姓名',
    update_user_name       varchar(128)                       null comment '修改人姓名'
)
    comment '进销存-订单明细表';

create index idx_jcx_order_item_goods_id
    on jcx_order_item (goods_id);

create index idx_jcx_order_item_order_id
    on jcx_order_item (order_id);

create index idx_jcx_order_item_tenant_id
    on jcx_order_item (tenant_id);

