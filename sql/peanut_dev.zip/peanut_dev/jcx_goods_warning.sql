create table jcx_goods_warning
(
    id                    bigint auto_increment comment 'ID 自增'
        primary key,
    report_no             varchar(255)                       null,
    goods_id              bigint                             null comment '商品ID',
    goods_name            varchar(255)                       null,
    cost_price            decimal(15, 6)                     null comment '成本价',
    sales_price           decimal(15, 6)                     null comment '成本价',
    warning_count         tinyint                            null,
    goods_gross_profit    decimal(15, 6)                     null comment '毛利',
    goods_net_profit      decimal(15, 6)                     null comment '净利',
    goods_inventory_count decimal(15, 6)                     null comment '库存',
    is_inventory          tinyint                            null,
    is_done               tinyint                            null,
    is_delete             bigint   default 0                 null comment '0 正常，非0已删除',
    create_time           datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by             bigint                             null comment '创建人',
    update_time           datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by             bigint                             null comment '修改人',
    trace_id              varchar(64)                        null comment '调用链路',
    version_num           int      default 0                 null comment '版本号',
    tenant_id             bigint                             null comment '租户ID',
    create_user_name      varchar(128)                       null comment '创建人姓名',
    update_user_name      varchar(128)                       null comment '修改人姓名'
)
    comment '进销存-库存预警表';

create index idx_jcx_goods_warning_goods_id
    on jcx_goods_warning (goods_id);

create index idx_jcx_goods_warning_tenant_id
    on jcx_goods_warning (tenant_id);

