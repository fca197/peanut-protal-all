create table aps_status
(
    id                  bigint auto_increment comment 'ID 自增'
        primary key,
    status_code         varchar(255)                       null,
    status_name         varchar(255)                       null,
    sort_index          int      default 0                 null comment '排序',
    sortIndex           int      default 0                 null comment '排序',
    factory_id          varchar(255)                       null,
    order_status_id     bigint                             null comment '订单状态',
    tenant_id           bigint                             null comment '租户ID',
    is_delete           bigint   default 0                 null comment '0 正常，非0已删除',
    create_time         datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by           bigint                             null comment '创建人',
    update_time         datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by           bigint                             null comment '修改人',
    trace_id            varchar(64)                        null comment '调用链路',
    version_num         int      default 0                 null comment '版本号',
    is_order_goods_init tinyint  default 0                 null comment '是否初始化订单状态',
    create_user_name    varchar(128)                       null comment '创建人姓名',
    update_user_name    varchar(128)                       null comment '修改人姓名'
)
    comment '排产状态表';

create index idx_aps_status_factory_id
    on aps_status (factory_id);

create index idx_aps_status_tenant_id
    on aps_status (tenant_id);

