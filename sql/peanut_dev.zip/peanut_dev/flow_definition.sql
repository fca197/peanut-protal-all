create table flow_definition
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    flow_name        varchar(64)                        null comment '工作流名称',
    flow_group_id    bigint                             null comment '工作流组ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    flow_key         varchar(64)                        null comment '流程key',
    tenant_id        bigint                             null comment '租户ID',
    flow_form_id     bigint                             null comment '流程表单id',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '工作定义表';

