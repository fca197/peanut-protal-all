create table task_instance_history
(
    id                  bigint                             not null comment 'ID 自增'
        primary key,
    instance_id         bigint                             null comment '实例ID',
    task_id             bigint                             null comment '任务ID',
    task_name           varchar(64)                        null comment '任务名称',
    task_def_id         varchar(64)                        null comment '任务节点ID',
    task_input          longtext                           null comment '入参',
    task_output         longtext                           null comment '返回值',
    task_exec_status    varchar(32)                        null comment '执行状态 ',
    exception_msg       longtext                           null comment '异常描述',
    use_time            int                                null comment '耗时',
    exec_loop           int                                null comment '次数',
    check_loop          int      default 0                 null comment '检查次数',
    check_exec_status   varchar(32)                        null comment '检查状态',
    check_exception_msg longtext                           null comment '检查异常信息',
    tenant_id           bigint                             null comment '租户ID',
    is_delete           bigint   default 0                 null comment '0 正常，非0已删除',
    create_time         datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by           bigint                             null comment '创建人',
    update_time         datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by           bigint                             null comment '修改人',
    trace_id            varchar(64)                        null comment '调用链路',
    version_num         int      default 0                 null comment '版本号',
    create_user_name    varchar(128)                       null comment '创建人姓名',
    update_user_name    varchar(128)                       null comment '修改人姓名'
)
    comment '任务实例历史';

create index idx_task_def_id
    on task_instance_history (task_def_id);

create index idx_task_id
    on task_instance_history (task_id);

