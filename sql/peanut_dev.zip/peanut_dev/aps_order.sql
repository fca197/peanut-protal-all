create table aps_order
(
    id                        bigint                                 null,
    order_no                  varchar(255)                           null,
    order_remark              varchar(255)                           null,
    order_status              bigint                                 null comment '订单状态',
    order_total_price         decimal(15, 6)                         null comment '成本价',
    goods_id                  bigint                                 null comment '商品ID',
    reserve_amount            decimal(15, 6)                         null comment '总价',
    reserve_datetime          varchar(255)                           null,
    finish_payed_amount       decimal(15, 6)                         null comment '总价',
    finish_payed_datetime     varchar(255)                           null,
    expected_make_finish_date date                                   null comment '预计制造完成时间',
    expected_delivery_date    date                                   null comment '预计交付日期',
    act_delivery_date         date                                   null comment '实际交付日期',
    make_finish_date          varchar(255)                           null,
    act_make_finish_date      date                                   null comment '实际完成时间',
    delivery_date             varchar(255)                           null,
    factory_id                bigint                                 null comment '工厂ID',
    tenant_id                 bigint                                 null comment '租户ID',
    is_delete                 bigint       default 0                 null comment '0 正常，非0已删除',
    create_time               datetime     default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                 bigint                                 null comment '创建人',
    update_time               datetime     default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                 bigint                                 null comment '修改人',
    trace_id                  varchar(64)                            null comment '调用链路',
    version_num               int          default 0                 null comment '版本号',
    urgency_level             int          default 0                 null comment '紧急度0最小,越大越紧急',
    scheduling_date           date                                   null comment '排产时间',
    order_no_parent           varchar(50)                            null comment '父订单号',
    is_warning                tinyint      default 0                 null comment '是否告警',
    warning_reason            varchar(256) default ''                null comment '告警原因',
    create_user_name          varchar(128)                           null comment '创建人姓名',
    update_user_name          varchar(128)                           null comment '修改人姓名'
)
    comment '订单表';

create index idx_aps_order_tenant_id
    on aps_order (tenant_id);

create index idx_order_no_parent
    on aps_order (order_no_parent);

