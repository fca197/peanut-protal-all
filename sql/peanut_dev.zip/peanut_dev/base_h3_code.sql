create table base_h3_code
(
    id               bigint                             not null comment 'ID 自增'
        primary key,
    lat              decimal(13, 6)                     null comment '纬度',
    lng              decimal(13, 6)                     null comment '经度',
    value0           bigint                             null comment '第0级对应的h3值',
    value1           bigint                             null comment '第1级对应的h3值',
    value2           bigint                             null comment '第2级对应的h3值',
    value3           bigint                             null comment '第3级对应的h3值',
    value4           bigint                             null comment '第4级对应的h3值',
    value5           bigint                             null comment '第5级对应的h3值',
    value6           bigint                             null comment '第6级对应的h3值',
    value7           bigint                             null comment '第7级对应的h3值',
    value8           bigint                             null comment '第8级对应的h3值',
    value9           bigint                             null comment '第9级对应的h3值',
    value10          bigint                             null comment '第10级对应的h3值',
    value11          bigint                             null comment '第11级对应的h3值',
    value12          bigint                             null comment '第12级对应的h3值',
    value13          bigint                             null comment '第13级对应的h3值',
    value14          bigint                             null comment '第14级对应的h3值',
    value15          bigint                             null comment '第15级对应的h3值',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment 'H3对应的值';

create index idx_lat
    on base_h3_code (lat);

create index idx_lng
    on base_h3_code (lng);

