create table aps_bom_supplier
(
    id                  bigint auto_increment comment 'ID 自增'
        primary key,
    bom_supplier_name   varchar(255)                       null comment '名称',
    bom_supplier_code   varchar(255)                       null comment '编号',
    bom_supplier_phone  varchar(255)                       null comment '手机',
    bom_supplier_tel    varchar(255)                       null comment '座机',
    bom_supplier_email  varchar(255)                       null comment '邮件',
    province_code       varchar(255)                       null comment '省编码',
    city_code           varchar(255)                       null comment '市编码',
    area_code           varchar(255)                       null comment '县编码',
    bom_supplier_addr   varchar(255)                       null comment '地址',
    bom_supplier_remark varchar(255)                       null comment '备注',
    supplier_status     varchar(255)                       null comment '状态',
    is_delete           bigint   default 0                 null comment '0 正常，非0已删除',
    create_time         datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by           bigint                             null comment '创建人',
    update_time         datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by           bigint                             null comment '修改人',
    trace_id            varchar(64)                        null comment '调用链路',
    version_num         int      default 0                 null comment '版本号',
    tenant_id           bigint                             null comment '租户ID',
    create_user_name    varchar(128)                       null comment '创建人姓名',
    update_user_name    varchar(128)                       null comment '修改人姓名'
)
    comment '供应商表';

create index idx_base_supplier_tenant_id
    on aps_bom_supplier (tenant_id);

