create table aps_project_config
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    sale_code        varchar(255)                       null,
    sale_name        varchar(255)                       null,
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    supplier_status  varchar(255)                       null,
    version_num      int      default 0                 null comment '版本号',
    is_value         tinyint                            null,
    parent_id        bigint                             null,
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '项目配置表';

create index idx_aps_project_config_parent_id
    on aps_project_config (parent_id);

create index idx_aps_project_config_tenant_id
    on aps_project_config (tenant_id);

