create table aps_order_goods_bom_kitting_version
(
    id                                      bigint auto_increment comment 'ID 自增'
        primary key,
    aps_order_goods_bom_kitting_template_id bigint                             null comment '模板ID',
    template_header_list                    json                               null comment '订单字段',
    kitting_version_no                      varchar(64)                        null comment '齐套版本编码',
    kitting_version_name                    varchar(64)                        null comment '齐套版本名称',
    kitting_version_source                  varchar(64)                        null comment '齐套来源',
    order_count                             bigint                             null comment '订单数量',
    kitting_success_count                   bigint                             null comment '齐套数',
    kitting_fail_count                      bigint                             null comment '非齐套数',
    kitting_rate                            decimal(5, 2)                      null comment '齐套率',
    kitting_status                          varchar(32)                        null comment '齐套状态 已齐套， 部分齐套，未齐套',
    kitting_missing_bom                     json                               null comment '缺失物料前10 [{id: label}]',
    biz_id                                  bigint                             null comment '业务ID',
    biz_type                                varchar(32)                        null comment '业务类型',
    version_create_param                    varchar(512)                       null comment '创建参数',
    create_date                             date                               null comment '计算日期',
    factory_id                              bigint                             null comment '工厂ID',
    tenant_id                               bigint                             null comment '租户ID',
    is_delete                               bigint   default 0                 null comment '0 正常，非0已删除',
    create_time                             datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                               bigint                             null comment '创建人',
    update_time                             datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                               bigint                             null comment '修改人',
    trace_id                                varchar(64)                        null comment '调用链路',
    version_num                             int      default 0                 null comment '版本号',
    goods_status_id                         bigint                             null comment '状态',
    bom_use_date                            date                               null comment '使用时间',
    create_user_name                        varchar(128)                       null comment '创建人姓名',
    update_user_name                        varchar(128)                       null comment '修改人姓名'
)
    comment '齐套检查版本';

