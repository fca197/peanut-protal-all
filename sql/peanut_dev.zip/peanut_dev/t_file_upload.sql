create table t_file_upload
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    tenant_id        bigint                             null comment '租户ID',
    file_name        varchar(255)                       null,
    file_size        varchar(255)                       null,
    local_file_path  varchar(255)                       null,
    cloud_file_path  varchar(255)                       null,
    expire_time      varchar(255)                       null,
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    file_type        varchar(255)                       null,
    file_suffix      varchar(255)                       null,
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '文件上传表';

create index idx_t_file_upload_tenant_id
    on t_file_upload (tenant_id);

