create table aps_order_goods_bom_kitting_version_order_bom
(
    id                         bigint auto_increment comment 'ID 自增'
        primary key,
    kitting_version_id         bigint                             null comment '齐套版本id',
    order_id                   bigint                             null comment '订单ID',
    order_no                   varchar(64)                        null comment '订单ID',
    order_make_begin_date_time datetime                           null comment '开始制造时间',
    goods_id                   bigint                             null comment '商品ID',
    goods_name                 varchar(64)                        null comment '商品名称',
    workshop_section_id        bigint                             null comment '工段Id',
    workshop_section_name      varchar(64)                        null comment '工段名称',
    workshop_station_id        bigint                             null comment '工位ID',
    workshop_station_name      varchar(64)                        null comment '工位名称',
    aps_room_id                bigint                             null comment '车间ID',
    aps_room_name              varchar(64)                        null comment '车间名称',
    bom_id                     bigint                             null comment '零件ID',
    bom_name                   varchar(64)                        null comment '零件名称',
    bom_usage                  decimal(10, 4)                     null comment '单个商品用量',
    lack_quantity              decimal(13, 4)                     null comment '缺少数量',
    inventory_before_count     decimal(10, 4)                     null comment '库存使用前数量',
    inventory_after_count      decimal(10, 4)                     null comment '库存使用后数量',
    goods_status_id            bigint                             null comment '状态ID',
    goods_status_name          varchar(64)                        null comment '状态名称',
    bom_use_date_time          datetime                           null comment '零件使用时间',
    create_date                date                               null comment '计算日期',
    factory_id                 bigint                             null comment '工厂ID',
    is_enough                  tinyint  default 0                 null comment '是否足够',
    tenant_id                  bigint                             null comment '租户ID',
    is_delete                  bigint   default 0                 null comment '0 正常，非0已删除',
    create_time                datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                  bigint                             null comment '创建人',
    update_time                datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                  bigint                             null comment '修改人',
    trace_id                   varchar(64)                        null comment '调用链路',
    version_num                int      default 0                 null comment '版本号',
    create_user_name           varchar(128)                       null comment '创建人姓名',
    update_user_name           varchar(128)                       null comment '修改人姓名'
)
    comment '齐套检查版本详情';

create index idx_bom_id
    on aps_order_goods_bom_kitting_version_order_bom (bom_id);

create index idx_kitting_version_id
    on aps_order_goods_bom_kitting_version_order_bom (kitting_version_id);

