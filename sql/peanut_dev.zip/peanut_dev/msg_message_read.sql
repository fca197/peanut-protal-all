create table msg_message_read
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    tenant_id        bigint                             null comment '租户ID',
    user_id          bigint                             null,
    last_read_time   varchar(255)                       null,
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        varchar(255)                       null,
    trace_id         varchar(64)                        null comment '调用链路',
    is_used          varchar(255)                       null,
    version_num      int      default 0                 null comment '版本号',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '消息已读表';

create index idx_msg_message_read_tenant_id
    on msg_message_read (tenant_id);

create index idx_msg_message_read_user_id
    on msg_message_read (user_id);

