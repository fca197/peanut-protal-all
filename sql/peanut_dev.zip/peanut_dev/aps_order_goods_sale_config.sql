create table aps_order_goods_sale_config
(
    id                 bigint auto_increment comment 'ID 自增'
        primary key,
    order_id           bigint                             null,
    goods_id           bigint                             null comment '商品ID',
    config_parent_id   bigint                             null comment '销售上级ID',
    config_parent_name varchar(64)                        null comment '上级名称',
    config_id          bigint                             null,
    config_name        varchar(64)                        null comment '本级名称',
    factory_id         bigint                             null comment '工厂ID',
    tenant_id          bigint                             null comment '租户ID',
    is_delete          bigint   default 0                 null comment '0 正常，非0已删除',
    create_time        datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by          bigint                             null comment '创建人',
    update_time        datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by          bigint                             null comment '修改人',
    trace_id           varchar(64)                        null comment '调用链路',
    version_num        int      default 0                 null comment '版本号',
    create_user_name   varchar(128)                       null comment '创建人姓名',
    update_user_name   varchar(128)                       null comment '修改人姓名'
)
    comment '订单商品销售配置表';

create index idx_aps_order_goods_sale_config_config_id
    on aps_order_goods_sale_config (config_id);

create index idx_aps_order_goods_sale_config_factory_id
    on aps_order_goods_sale_config (factory_id);

create index idx_aps_order_goods_sale_config_goods_id
    on aps_order_goods_sale_config (goods_id);

create index idx_aps_order_goods_sale_config_order_id
    on aps_order_goods_sale_config (order_id);

create index idx_aps_order_goods_sale_config_tenant_id
    on aps_order_goods_sale_config (tenant_id);

