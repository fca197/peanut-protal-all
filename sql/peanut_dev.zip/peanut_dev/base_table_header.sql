create table base_table_header
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    biz_key          varchar(255)                       null,
    field_name       varchar(255)                       null,
    show_name        varchar(255)                       null,
    width_px         varchar(255)                       null,
    sort_index       int                                null comment '排序',
    is_picture       varchar(255)                       null,
    plan_status      varchar(255)                       null,
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        varchar(255)                       null,
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    tenant_id        bigint                             null comment '租户ID',
    create_user_name varchar(128)                       null comment '创建人姓名',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '表头配置表';

create index idx_base_table_header_tenant_id
    on base_table_header (tenant_id);

create index idx_biz_key
    on base_table_header (biz_key);

