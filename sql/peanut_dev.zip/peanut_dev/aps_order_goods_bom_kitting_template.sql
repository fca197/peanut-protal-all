create table aps_order_goods_bom_kitting_template
(
    id                                      bigint auto_increment comment 'ID 自增'
        primary key,
    kitting_template_no                     varchar(64)                        null comment '模板编号',
    kitting_template_name                   varchar(64)                        null comment '模板名称',
    kitting_template_sale_config_list       json                               null comment '销售配置',
    kitting_template_order_config_list      json                               null comment '订单配置',
    kitting_template_order_user_config_list json                               null comment '订单配置',
    factory_id                              bigint                             null comment '工厂ID',
    tenant_id                               bigint                             null comment '租户ID',
    is_delete                               bigint   default 0                 null comment '0 正常，非0已删除',
    create_time                             datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                               bigint                             null comment '创建人',
    update_time                             datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                               bigint                             null comment '修改人',
    trace_id                                varchar(64)                        null comment '调用链路',
    version_num                             int      default 0                 null comment '版本号',
    create_user_name                        varchar(128)                       null comment '创建人姓名',
    update_user_name                        varchar(128)                       null comment '修改人姓名'
)
    comment '齐套模板';

