create table t_login_account
(
    id               bigint auto_increment comment 'ID 自增'
        primary key,
    user_name        varchar(255)                         null,
    login_phone      varchar(255)                         not null,
    pwd              varchar(255)                         null,
    is_delete        bigint     default 0                 null comment '0 正常，非0已删除',
    create_time      datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                               null comment '创建人',
    update_time      datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        varchar(255)                         null,
    trace_id         varchar(64)                          null comment '调用链路',
    tenant_id        bigint                               null comment '租户ID',
    version_num      int        default 0                 null comment '版本号',
    user_pwd         varchar(255)                         null,
    is_admin         tinyint(1) default 0                 null comment '是否是管理员',
    create_user_name varchar(128)                         null comment '创建人姓名',
    update_user_name varchar(128)                         null comment '修改人姓名',
    constraint un_login_phone
        unique (login_phone, is_delete)
)
    comment '登录账号表';

create index idx_t_login_account_tenant_id
    on t_login_account (tenant_id);

