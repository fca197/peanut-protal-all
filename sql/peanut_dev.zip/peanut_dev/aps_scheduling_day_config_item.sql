create table aps_scheduling_day_config_item
(
    id                bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_day_id bigint                               null comment '排程版本ID',
    process_id        bigint                               null comment '工艺路径ID',
    room_id           bigint                               null comment '车间ID',
    status_id         bigint                               null comment '状态ID',
    config_biz_type   varchar(255)                         null comment '配置类型 sale,part,bom ,sleep',
    config_biz_id     bigint                               null comment '配置业务ID',
    config_biz_name   varchar(255)                         null comment '配置业务名称',
    config_biz_num    bigint                               null comment '配置业务数量',
    config_biz_time   bigint                               null comment '配置业务耗时(秒)',
    is_default        tinyint(1) default 0                 null comment '是否默认 0 否,1 是',
    tenant_id         bigint                               null comment '租户ID',
    is_delete         bigint     default 0                 null comment '0 正常，非0已删除',
    create_time       datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by         bigint                               null comment '创建人',
    update_time       datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by         bigint                               null comment '修改人',
    trace_id          varchar(64)                          null comment '调用链路',
    version_num       int        default 0                 null comment '版本号',
    create_user_name  varchar(128)                         null comment '创建人姓名',
    update_user_name  varchar(128)                         null comment '修改人姓名'
)
    comment '排程版本配置表';

create index scheduling_day_id
    on aps_scheduling_day_config_item (scheduling_day_id);

