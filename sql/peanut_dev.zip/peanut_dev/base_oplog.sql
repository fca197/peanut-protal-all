create table base_oplog
(
    id               bigint                             not null comment 'id'
        primary key,
    content          varchar(128)                       null comment '操作内容',
    business_key     varchar(128)                       null comment '业务Key',
    method_name      varchar(128)                       null comment '方法名称',
    business_type    varchar(128)                       null comment '业务类型',
    business_type0   varchar(128)                       null comment '业务类型',
    business_type1   varchar(128)                       null comment '业务类型',
    business_type2   varchar(128)                       null comment '业务类型',
    business_type3   varchar(128)                       null comment '业务类型',
    business_type4   varchar(128)                       null comment '业务类型',
    url              varchar(128)                       null comment '请求地址',
    use_time         varchar(128)                       null comment '耗时',
    param_name       varchar(128)                       null comment '参数名 参数1,参数2',
    req_body         longtext                           null comment '请求入参',
    is_success       tinyint                            null comment '是否成功',
    result_str       longtext                           null comment '请求入参',
    remark           varchar(128)                       null comment '备注',
    create_user_name varchar(128)                       null comment '创建人姓名',
    tenant_id        bigint                             null comment '租户ID',
    is_delete        bigint   default 0                 null comment '0 正常，非0已删除',
    create_time      datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by        bigint                             null comment '创建人',
    update_time      datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by        bigint                             null comment '修改人',
    trace_id         varchar(64)                        null comment '调用链路',
    version_num      int      default 0                 null comment '版本号',
    login_phone      varchar(64)                        null comment '登录手机号',
    update_user_name varchar(128)                       null comment '修改人姓名'
)
    comment '操作日志';

