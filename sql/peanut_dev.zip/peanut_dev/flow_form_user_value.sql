create table flow_form_user_value
(
    id                      bigint auto_increment comment 'ID 自增'
        primary key,
    process_instance_id     varchar(255)                         null comment '流程实例ID',
    business_key            varchar(64)                          null comment '业务主键',
    form_id                 bigint                               null comment '表单ID',
    form_item_default_value varchar(255)                         null comment '表单默认值',
    form_item_filed         varchar(255)                         null comment '表单字段',
    form_item_name          varchar(255)                         null comment '表单名称',
    form_item_value         varchar(255)                         null comment '表单值',
    form_item_value_type    varchar(255)                         null comment '表单值类型',
    is_add_flow_value       tinyint(1) default 0                 null comment '是否添加流程表单值 0 否,1 是',
    is_required             tinyint(1) default 0                 null comment '是否必填 0 否,1 是',
    lose_focus_event        varchar(255)                         null comment '失去焦点事件',
    sort_index              int                                  null comment '排序',
    user_value              varchar(255)                         null comment '用户值',
    tenant_id               bigint                               null comment '租户ID',
    is_delete               bigint     default 0                 null comment '0 正常，非0已删除',
    create_time             datetime   default CURRENT_TIMESTAMP null comment '创建时间',
    create_by               bigint                               null comment '创建人',
    update_time             datetime   default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by               bigint                               null comment '修改人',
    trace_id                varchar(64)                          null comment '调用链路',
    version_num             int        default 0                 null comment '版本号',
    create_user_name        varchar(128)                         null comment '创建人姓名',
    update_user_name        varchar(128)                         null comment '修改人姓名'
)
    comment '工作流表单用户数据表';

create index idx_business_key
    on flow_form_user_value (business_key);

create index idx_process_instance_id
    on flow_form_user_value (process_instance_id);

