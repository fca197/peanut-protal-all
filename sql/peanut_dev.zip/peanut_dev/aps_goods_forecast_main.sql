create table aps_goods_forecast_main
(
    id                  bigint auto_increment comment 'ID 自增'
        primary key,
    goods_id            bigint                             null comment '商品ID',
    forecast_no         varchar(255)                       null comment '预测编码',
    forecast_name       varchar(255)                       null comment '预测名称',
    forecast_begin_date varchar(255)                       null comment '开始时间',
    forecast_end_date   varchar(255)                       null comment '结束时间',
    tenant_id           bigint                             null comment '租户ID',
    is_delete           bigint   default 0                 null comment '0 正常，非0已删除',
    create_time         datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by           bigint                             null comment '创建人',
    update_time         datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by           bigint                             null comment '修改人',
    trace_id            varchar(64)                        null comment '调用链路',
    version_num         int      default 0                 null comment '版本号',
    month               varchar(255)                       null,
    months              varchar(255)                       null,
    factory_id          bigint                             null comment '工厂ID',
    create_user_name    varchar(128)                       null comment '创建人姓名',
    update_user_name    varchar(128)                       null comment '修改人姓名'
)
    comment '预测主表';

create index idx_aps_goods_forecast_main_factory_id
    on aps_goods_forecast_main (factory_id);

create index idx_aps_goods_forecast_main_goods_id
    on aps_goods_forecast_main (goods_id);

create index idx_aps_goods_forecast_main_tenant_id
    on aps_goods_forecast_main (tenant_id);

