create table aps_scheduling_issue_item
(
    id                    bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_version_id bigint                             null comment '排产版本ID',
    current_day           varchar(255)                       null comment '当前日期',
    order_id              bigint                             null comment '订单ID',
    goods_id              bigint                             null comment '商品ID',
    number_index          int                                null comment '生产序号',
    factory_id            bigint                             null comment '工厂id',
    urgency_level         int      default 0                 null comment '订单紧急度',
    tenant_id             bigint                             null comment '租户ID',
    is_delete             bigint   default 0                 null comment '0 正常，非0已删除',
    create_time           datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by             bigint                             null comment '创建人',
    update_time           datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by             varchar(255)                       null,
    trace_id              varchar(64)                        null comment '调用链路',
    version_num           int      default 0                 null comment '版本号',
    order_no              varchar(64)                        not null comment '订单号',
    create_user_name      varchar(128)                       null comment '创建人姓名',
    update_user_name      varchar(128)                       null comment '修改人姓名'
)
    comment '排产下发详情';

create index idx_current_day
    on aps_scheduling_issue_item (current_day);

create index idx_factory_id
    on aps_scheduling_issue_item (factory_id);

