create table aps_scheduling_day_config_version_detail_machine
(
    id                       bigint auto_increment comment 'ID 自增'
        primary key,
    scheduling_day_id        bigint                             null comment '版本ID',
    order_id                 bigint                             null comment '订单ID',
    order_step_index         bigint                             null comment '制造ID',
    order_create_index       bigint                             null comment '制造ID',
    machine_id               bigint                             null comment '机器ID',
    status_id                bigint                             null comment '状态ID',
    goods_status_name        varchar(64)                        null comment '状态名称',
    begin_date_time          datetime                           null comment '开始时间',
    end_date_time            datetime                           null comment '结束时间',
    start_second             bigint                             null comment '开始秒',
    end_second               bigint                             null comment '结束秒',
    use_time                 bigint                             null comment '耗时（秒）',
    produce_process_id       bigint                             null comment '路径ID',
    goods_status_id          bigint                             null comment '商品状态ID',
    machine_workstation_id   bigint                             null comment '工作站ID',
    machine_workstation_name varchar(64)                        null comment '工作站名称',
    machine_name             varchar(64)                        null comment '机器名称',
    max_power                int                                null comment '最大功率',
    factory_id               bigint                             null comment '工厂',
    sort_index               int                                null comment '排序',
    tenant_id                bigint                             null comment '租户ID',
    is_delete                bigint   default 0                 null comment '0 正常，非0已删除',
    create_time              datetime default CURRENT_TIMESTAMP null comment '创建时间',
    create_by                bigint                             null comment '创建人',
    update_time              datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '修改时间',
    update_by                bigint                             null comment '修改人',
    trace_id                 varchar(64)                        null comment '调用链路',
    version_num              int      default 0                 null comment '版本号',
    create_user_name         varchar(128)                       null comment '创建人姓名',
    update_user_name         varchar(128)                       null comment '修改人姓名'
)
    comment '排程版本详情_机器';

create index idx_scheduling_day_id
    on aps_scheduling_day_config_version_detail_machine (scheduling_day_id);

